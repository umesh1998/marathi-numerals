"""marathi-numerals: small helpers for Marathi (Devanagari) digits and
Indian-style number formatting (lakh / crore grouping)."""

__version__ = "0.1.0"

_DEVANAGARI = "०१२३४५६७८९"
_TO_MARATHI = str.maketrans("0123456789", _DEVANAGARI)
_TO_ENGLISH = str.maketrans(_DEVANAGARI, "0123456789")


def to_marathi_digits(value) -> str:
    """Convert English digits to Marathi digits. '2026' -> '२०२६'."""
    return str(value).translate(_TO_MARATHI)


def to_english_digits(value) -> str:
    """Convert Marathi digits to English digits. '२०२६' -> '2026'."""
    return str(value).translate(_TO_ENGLISH)


def format_indian(number, decimals: int = 0, marathi: bool = False) -> str:
    """Format a number with Indian grouping.

    format_indian(1234567)               -> '12,34,567'
    format_indian(1234567.5, 2)          -> '12,34,567.50'
    format_indian(1234567, marathi=True) -> '१२,३४,५६७'
    """
    negative = float(number) < 0
    text = f"{abs(float(number)):.{decimals}f}"
    whole, _, fraction = text.partition(".")

    if len(whole) > 3:
        head, tail = whole[:-3], whole[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        whole = ",".join(groups) + "," + tail

    result = whole + ("." + fraction if fraction else "")
    if negative:
        result = "-" + result
    return to_marathi_digits(result) if marathi else result


def main():
    import sys

    if len(sys.argv) < 2:
        print("Usage: python marathi_numerals.py <number>")
        raise SystemExit(1)
    arg = sys.argv[1]
    plain = to_english_digits(arg)
    print("Marathi digits :", to_marathi_digits(plain))
    print("English digits :", plain)
    try:
        print("Indian format  :", format_indian(plain))
    except ValueError:
        pass


if __name__ == "__main__":
    main()
