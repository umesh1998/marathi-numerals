from marathi_numerals import to_marathi_digits, to_english_digits, format_indian


def test_to_marathi():
    assert to_marathi_digits(2026) == "२०२६"


def test_to_english():
    assert to_english_digits("२०२६") == "2026"


def test_mixed_text():
    assert to_marathi_digits("Rs 500") == "Rs ५००"


def test_indian_grouping():
    assert format_indian(1234567) == "12,34,567"
    assert format_indian(999) == "999"
    assert format_indian(1000) == "1,000"
    assert format_indian(10000000) == "1,00,00,000"


def test_decimals_and_negative():
    assert format_indian(1234567.5, 2) == "12,34,567.50"
    assert format_indian(-100000) == "-1,00,000"


def test_marathi_output():
    assert format_indian(1234567, marathi=True) == "१२,३४,५६७"
