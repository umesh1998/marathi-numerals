# marathi-numerals

A tiny, dependency-free Python library for working with Marathi (Devanagari) digits and Indian-style number formatting.

## Features
- English digits to Marathi digits: `2026` -> `२०२६`
- Marathi digits to English digits: `२०२६` -> `2026`
- Indian grouping (lakh / crore): `1234567` -> `12,34,567`
- Optional Marathi output: `१२,३४,५६७`

## Usage
```python
from marathi_numerals import to_marathi_digits, to_english_digits, format_indian

to_marathi_digits(2026)                 # '२०२६'
to_english_digits("२०२६")               # '2026'
format_indian(1234567)                  # '12,34,567'
format_indian(1234567.5, 2)             # '12,34,567.50'
format_indian(1234567, marathi=True)    # '१२,३४,५६७'
```

Command line:
```
python marathi_numerals.py 1234567
```

## Run tests
```
pip install pytest
pytest
```

## Contributing
Issues and pull requests are welcome. Ideas: number to Marathi words (e.g. 25 -> पंचवीस), Marathi date formatting, currency helpers.

## License
MIT
